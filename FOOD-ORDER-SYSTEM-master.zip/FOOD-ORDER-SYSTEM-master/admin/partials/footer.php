 <!----Footer Section Starts------>
 <div class="footer">
    <div class="wrapper">
         <p class="text-center">2022 All rights reserved, WOW Food.</p>
    </div>
    </div>
    <!----Footer Section Ends------>
</body>    
</html>