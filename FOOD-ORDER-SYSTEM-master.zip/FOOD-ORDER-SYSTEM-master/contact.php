<?php include('partials-front/menu.php') ?>

<h1 class="text-center container">Contacts</h1>

<?php include('partials-front/footer.php') ?>